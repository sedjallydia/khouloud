package com.ingweb.tp.rendezVousService;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
class RendezVous {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private LocalDateTime heure;
	private Long clientID;
	private Long profID;
}

@Repository
interface RendezVousRepository extends JpaRepository<RendezVous,Long> {
}

@RestController
class emplRestControler {

	private RendezVousRepository rendezVousRepository;
	public emplRestControler(RendezVousRepository rendezVousRepository) {
		this.rendezVousRepository =rendezVousRepository;
	}
	//http://localhost:8081/lesRendezVous
	@GetMapping(path="/lesRendezVous")
	public List<RendezVous> getAllEmp(){
		return rendezVousRepository.findAll();
	}
	@GetMapping(value="/lesRendezVous/{id}")
	public RendezVous getEmp(@PathVariable(name="id") Long id){
		return rendezVousRepository.findById(id).get();
	}
	@PutMapping(value="/lesRendezVous/{id}")
	public RendezVous updateEmp(@PathVariable(name="id") Long id, @RequestBody RendezVous emp){
		emp.setId(id);
		return rendezVousRepository.save(emp);
	}
	@PostMapping(value="/lesRendezVous")
	public RendezVous save(@RequestBody RendezVous emp){
		return rendezVousRepository.save(emp);

	}
	@DeleteMapping(value="/lesRendezVous/{id}")
	public void delete(@PathVariable(name="id") Long id){
		rendezVousRepository.deleteById(id);
	}
}
@SpringBootApplication
public class RendezVousServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RendezVousServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner star(RendezVousRepository rendezVousRepository) {
		return args ->{
			rendezVousRepository.save(new RendezVous(null,LocalDateTime.of(2024, 10, 30, 10, 0),3L,1L));
			rendezVousRepository.save(new RendezVous(null,LocalDateTime.of(2024, 10, 30, 14, 0),4L,1L));
			rendezVousRepository.findAll().forEach(emp-> {System.out.println(emp.toString());});
		};
	}
}
