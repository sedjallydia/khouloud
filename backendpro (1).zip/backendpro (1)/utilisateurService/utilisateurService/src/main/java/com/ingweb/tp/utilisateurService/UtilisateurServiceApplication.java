package com.ingweb.tp.utilisateurService;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
class Utilisateur {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String adressMail;
	private String motDePasse;
	private String role;
}

@Repository
interface UtilisateurRepository extends JpaRepository<Utilisateur,Long> {
}

@RestController
class emplRestControler {

	private UtilisateurRepository utilisateurRepository;
	public emplRestControler(UtilisateurRepository utilisateurRepository) {
		this.utilisateurRepository =utilisateurRepository;
	}
	//http://localhost:8081/utilisateurs
	@GetMapping(path="/utilisateurs")
	public List<Utilisateur> getAllEmp(){
		return utilisateurRepository.findAll();
	}
	@GetMapping(value="/utilisateurs/{id}")
	public Utilisateur getEmp(@PathVariable(name="id") Long id){
		return utilisateurRepository.findById(id).get();
	}
	@PutMapping(value="/utilisateurs/{id}")
	public Utilisateur updateEmp(@PathVariable(name="id") Long id, @RequestBody Utilisateur emp){
		emp.setId(id);
		return utilisateurRepository.save(emp);
	}
	@PostMapping(value="/utilisateurs")
	public Utilisateur save(@RequestBody Utilisateur emp){
		return utilisateurRepository.save(emp);

	}
	@DeleteMapping(value="/utilisateurs/{id}")
	public void delete(@PathVariable(name="id") Long id){
		utilisateurRepository.deleteById(id);
	}

}
@SpringBootApplication
public class UtilisateurServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UtilisateurServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner star(UtilisateurRepository utilisateurRepository) {
		return args ->{
			utilisateurRepository.save(new Utilisateur(null,"prof1@gmail.com","111", "prof")); //id = 1
			utilisateurRepository.save(new Utilisateur(null,"prof2@gmail.com","222", "prof")); //id = 2
			utilisateurRepository.save(new Utilisateur(null,"client1@gmail.com", "111", "client")); //id = 3
			utilisateurRepository.save(new Utilisateur(null,"client2@gmail.com", "222", "client")); //id = 4
			utilisateurRepository.findAll().forEach(emp-> {System.out.println(emp.toString());});
		};
	}
}
