package com.ingweb.tp.disponibiliteService;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
class Disponibilite {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDateTime dateDebut;
	private LocalDateTime dateFin;
	private Long profID;
}

@Repository
interface DisponibiliteRepository extends JpaRepository<Disponibilite, Long> {
}

@RestController
class emplRestControler {

	private DisponibiliteRepository disponibiliteRepository;

	public emplRestControler(DisponibiliteRepository disponibiliteRepository) {
		this.disponibiliteRepository = disponibiliteRepository;
	}

	// http://localhost:8081/disponibilites
	@GetMapping(path = "/disponibilites")
	public List<Disponibilite> getAllEmp() {
		return disponibiliteRepository.findAll();
	}

	@GetMapping(value = "/disponibilites/{id}")
	public Disponibilite getEmp(@PathVariable(name = "id") Long id) {
		return disponibiliteRepository.findById(id).get();
	}

	@PutMapping(value = "/disponibilites/{id}")
	public Disponibilite updateEmp(@PathVariable(name = "id") Long id, @RequestBody Disponibilite emp) {
		emp.setId(id);
		return disponibiliteRepository.save(emp);
	}

	@PostMapping(value = "/disponibilites")
	public Disponibilite save(@RequestBody Disponibilite emp) {
		return disponibiliteRepository.save(emp);

	}

	@DeleteMapping(value = "/disponibilites/{id}")
	public void delete(@PathVariable(name = "id") Long id) {
		disponibiliteRepository.deleteById(id);
	}

}

@SpringBootApplication
public class DisponibiliteServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisponibiliteServiceApplication.class, args);
	}

	@Bean
	CommandLineRunner star(DisponibiliteRepository disponibiliteRepository) {
		return args -> {
			disponibiliteRepository.save(new Disponibilite((Long) null, LocalDateTime.of(2024, 10, 30, 10, 0),
					LocalDateTime.of(2024, 10, 30, 11, 0), 1L));
			disponibiliteRepository.save(new Disponibilite(null, LocalDateTime.of(2024, 10, 30, 14, 0),
					LocalDateTime.of(2024, 10, 30, 15, 0), 1L));
			disponibiliteRepository.findAll().forEach(emp -> {
				System.out.println(emp.toString());
			});
		};
	}
}
